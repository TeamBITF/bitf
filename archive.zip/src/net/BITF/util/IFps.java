package net.BITF.util;

public interface IFps {
	public void update();
}
